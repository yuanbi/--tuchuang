﻿import json
import random
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import quote, unquote, urlparse

HOST = "0.0.0.0"
PORT = 8000
BASE_DIR = Path(__file__).resolve().parent
CONFIG_FILE = BASE_DIR / "config.json"
IMAGES_DIR = BASE_DIR / "images"


HTML_INDEX = """<!doctype html>
<html lang=\"zh-CN\">
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
  <title>随机图床</title>
  <style>
    body {
      font-family: \"Segoe UI\", sans-serif;
      max-width: 760px;
      margin: 40px auto;
      padding: 0 16px;
      line-height: 1.6;
    }
    code {
      background: #f5f5f5;
      padding: 2px 6px;
      border-radius: 4px;
    }
    a {
      color: #0b57d0;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <h1>随机图床已启动</h1>
  <p>随机访问链接：<a href=\"/random\" target=\"_blank\"><code>/random</code></a></p>
  <p>JSON 接口：<a href=\"/api/random\" target=\"_blank\"><code>/api/random</code></a></p>
  <p>后台管理：<a href=\"/admin\" target=\"_blank\"><code>/admin</code></a></p>
  <p>请在 <code>config.json</code> 的 <code>images</code> 数组里配置图片地址。</p>
  <ul>
    <li><code>https://...</code>：远程图片 URL</li>
    <li><code>/images/xxx.jpg</code>：本地图片路径</li>
    <li><code>xxx.jpg</code>：会自动当作 <code>/images/xxx.jpg</code></li>
  </ul>
</body>
</html>"""

HTML_ADMIN = """<!doctype html>
<html lang=\"zh-CN\">
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
  <title>图床后台</title>
  <style>
    body {
      font-family: \"Segoe UI\", sans-serif;
      max-width: 860px;
      margin: 30px auto;
      padding: 0 16px;
      line-height: 1.5;
    }
    .row {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-bottom: 10px;
    }
    input {
      flex: 1;
      min-width: 280px;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 8px;
    }
    button {
      padding: 10px 14px;
      border: 0;
      border-radius: 8px;
      background: #0b57d0;
      color: #fff;
      cursor: pointer;
    }
    button.secondary {
      background: #4b5563;
    }
    ul {
      list-style: none;
      padding: 0;
      margin: 12px 0;
    }
    li {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding: 10px;
      border: 1px solid #eee;
      border-radius: 8px;
      margin-bottom: 8px;
    }
    .item-text {
      word-break: break-all;
      flex: 1;
    }
    .delete-btn {
      background: #dc2626;
      padding: 6px 10px;
    }
    #status {
      color: #1f2937;
      min-height: 24px;
    }
  </style>
</head>
<body>
  <h1>图床后台</h1>
  <p>在这里管理随机图片列表，保存后立即生效。</p>

  <div class=\"row\">
    <input id=\"imageInput\" placeholder=\"输入图片 URL 或本地文件名，例如 https://a.com/a.jpg 或 local.jpg\" />
    <button id=\"addBtn\">添加</button>
  </div>

  <div class=\"row\">
    <button id=\"saveBtn\">保存配置</button>
    <button id=\"reloadBtn\" class=\"secondary\">重新加载</button>
    <button id=\"testBtn\" class=\"secondary\">测试随机链接</button>
  </div>

  <div id=\"status\"></div>
  <ul id=\"imageList\"></ul>

  <script>
    const imageInput = document.getElementById("imageInput");
    const imageList = document.getElementById("imageList");
    const statusEl = document.getElementById("status");
    const addBtn = document.getElementById("addBtn");
    const saveBtn = document.getElementById("saveBtn");
    const reloadBtn = document.getElementById("reloadBtn");
    const testBtn = document.getElementById("testBtn");

    let images = [];

    function setStatus(text, isError = false) {
      statusEl.textContent = text;
      statusEl.style.color = isError ? "#dc2626" : "#1f2937";
    }

    function render() {
      imageList.innerHTML = "";
      images.forEach((item, index) => {
        const li = document.createElement("li");
        const span = document.createElement("span");
        span.className = "item-text";
        span.textContent = item;

        const del = document.createElement("button");
        del.className = "delete-btn";
        del.textContent = "删除";
        del.addEventListener("click", () => {
          images.splice(index, 1);
          render();
        });

        li.appendChild(span);
        li.appendChild(del);
        imageList.appendChild(li);
      });

      if (images.length === 0) {
        setStatus("当前没有图片，请先添加。");
      } else {
        setStatus("当前共 " + images.length + " 张图片，记得点击“保存配置”。");
      }
    }

    async function loadImages() {
      try {
        const resp = await fetch("/api/images");
        const data = await resp.json();
        images = Array.isArray(data.images) ? data.images : [];
        render();
      } catch (err) {
        setStatus("加载失败：" + err, true);
      }
    }

    addBtn.addEventListener("click", () => {
      const value = imageInput.value.trim();
      if (!value) {
        setStatus("请输入有效图片地址。", true);
        return;
      }
      images.push(value);
      imageInput.value = "";
      render();
    });

    saveBtn.addEventListener("click", async () => {
      try {
        const resp = await fetch("/api/images", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ images })
        });
        const data = await resp.json();
        if (!resp.ok) {
          throw new Error(data.error || "保存失败");
        }
        setStatus("保存成功，当前共 " + data.count + " 张图片。");
      } catch (err) {
        setStatus("保存失败：" + err, true);
      }
    });

    reloadBtn.addEventListener("click", loadImages);
    testBtn.addEventListener("click", () => window.open("/random", "_blank"));
    imageInput.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        addBtn.click();
      }
    });

    loadImages();
  </script>
</body>
</html>"""


def load_images() -> List[str]:
    if not CONFIG_FILE.exists():
        return []

    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError:
        return []

    images = data.get("images", []) if isinstance(data, dict) else []
    return [item.strip() for item in images if isinstance(item, str) and item.strip()]


def save_images(images: List[str]) -> None:
    clean_images = [item.strip() for item in images if isinstance(item, str) and item.strip()]
    payload = {"images": clean_images}
    CONFIG_FILE.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def normalize_target(item: str) -> str:
    if item.startswith("http://") or item.startswith("https://"):
        return item
    if item.startswith("/"):
        return item
    return f"/images/{quote(item)}"


def pick_random_image() -> Optional[str]:
    images = load_images()
    if not images:
        return None
    return normalize_target(random.choice(images))


class ImageHostHandler(BaseHTTPRequestHandler):
    server_version = "RandomImageHost/1.1"

    def _send_text(self, status: int, body: str, content_type: str = "text/plain; charset=utf-8") -> None:
        encoded = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False)
        self._send_text(status, body, "application/json; charset=utf-8")

    def _redirect(self, location: str) -> None:
        self.send_response(302)
        self.send_header("Location", location)
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def _read_json_body(self) -> Optional[Dict]:
        content_length = self.headers.get("Content-Length", "0")
        try:
            body_size = int(content_length)
        except ValueError:
            return None

        if body_size <= 0:
            return None

        raw_body = self.rfile.read(body_size)
        try:
            data = json.loads(raw_body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            return None

        return data if isinstance(data, dict) else None

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/" or path == "/index.html":
            self._send_text(200, HTML_INDEX, "text/html; charset=utf-8")
            return

        if path == "/admin":
            self._send_text(200, HTML_ADMIN, "text/html; charset=utf-8")
            return

        if path == "/health":
            self._send_json(200, {"ok": True})
            return

        if path == "/random":
            target = pick_random_image()
            if target is None:
                self._send_json(
                    500,
                    {
                        "error": "No images configured",
                        "hint": "Add image URLs to config.json -> images",
                    },
                )
                return
            self._redirect(target)
            return

        if path == "/api/random":
            target = pick_random_image()
            if target is None:
                self._send_json(
                    500,
                    {
                        "error": "No images configured",
                        "hint": "Add image URLs to config.json -> images",
                    },
                )
                return
            self._send_json(200, {"url": target})
            return

        if path == "/api/images":
            self._send_json(200, {"images": load_images()})
            return

        if path.startswith("/images/"):
            relative = unquote(path[len("/images/"):])
            file_path = (IMAGES_DIR / relative).resolve()

            try:
                file_path.relative_to(IMAGES_DIR.resolve())
            except ValueError:
                self._send_text(403, "Forbidden")
                return

            if not file_path.exists() or not file_path.is_file():
                self._send_text(404, "Image not found")
                return

            suffix = file_path.suffix.lower()
            content_type = {
                ".jpg": "image/jpeg",
                ".jpeg": "image/jpeg",
                ".png": "image/png",
                ".gif": "image/gif",
                ".webp": "image/webp",
                ".bmp": "image/bmp",
                ".svg": "image/svg+xml",
            }.get(suffix, "application/octet-stream")

            data = file_path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)
            return

        self._send_text(404, "Not Found")

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/images":
            data = self._read_json_body()
            if not data or not isinstance(data.get("images"), list):
                self._send_json(
                    400,
                    {
                        "error": "Invalid body",
                        "hint": "Use JSON: {\"images\": [\"https://...\", \"local.jpg\"]}",
                    },
                )
                return

            save_images(data["images"])
            self._send_json(200, {"ok": True, "count": len(load_images())})
            return

        self._send_text(404, "Not Found")


def run() -> None:
    server = HTTPServer((HOST, PORT), ImageHostHandler)
    print("Random image host running: http://127.0.0.1:{0}".format(PORT))
    server.serve_forever()


if __name__ == "__main__":
    run()
